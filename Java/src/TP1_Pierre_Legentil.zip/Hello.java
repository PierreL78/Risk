/* Author: Pierre Legentil */

//4.1.2
public class Hello {
	public static void main(String[] args) {
		System.out.println("Hello le monde");
	}
}


//4.1.3

/* On constate que le programme ne marche pas */


